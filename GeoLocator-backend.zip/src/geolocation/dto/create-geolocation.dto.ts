export class CreateGeolocationDto {}
