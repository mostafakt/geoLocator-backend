export class Geolocation {}
